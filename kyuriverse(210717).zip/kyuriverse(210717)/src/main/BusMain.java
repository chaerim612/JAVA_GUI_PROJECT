package main;

import frame.FrameBase;
import frame.FrameBegin;

public class BusMain {

	public static void main(String[] args) {
		FrameBase.getInstance(new FrameBegin());
	}

}
